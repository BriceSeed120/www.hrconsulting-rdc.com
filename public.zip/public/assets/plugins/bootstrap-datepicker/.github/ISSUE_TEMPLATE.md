### Expected behaviour
Tell us what should happen.

### Actual behaviour
Tell us what happens instead.

### Datepicker version used

ex. 1.6.1.

### Example code

Jsfiddle example to reproduce the problem.
