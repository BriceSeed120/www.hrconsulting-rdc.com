<?php

return [
    'category' => [
        "1" => "Rooms & Suites",
        "2" =>"Facilities",
        "3" => "Restaurants",
        "4" =>"Meetings & Events"
    ]
];
?>